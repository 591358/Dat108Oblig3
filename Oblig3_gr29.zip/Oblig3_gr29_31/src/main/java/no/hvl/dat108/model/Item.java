package no.hvl.dat108.model;

public class Item {
	private String item;

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

}
